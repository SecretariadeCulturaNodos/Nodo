        // CARRUSEL 1
        $('#owl-1').owlCarousel({
            loop: true,
            margin: 10,
            nav: false,
            responsive: {
                  0: {items:1},
                450: { items:1},
                640: { items:2},
                768: { items:2},
                992: { items:3},
               1200: { items:3}
            }
        });
        var owl = $('.owl-carousel.exh');
        owl.owlCarousel();
        // Go to the next item
        $('.exh.customNextBtn').click(function() {
            owl.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.exh.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owl.trigger('prev.owl.carousel', [300]);
        })

        // CARRUSEL 2
        $('#owl-2').owlCarousel({
            loop: true,
            touchDrag: true,
            margin: 10,
            nav: false,
            responsive: {
                  0: {items:1},
                450: { items:1},
                640: { items:2},
                768: { items:2},
                992: { items:3},
               1200: { items:3}
            }
        });
        var owl2 = $('.owl-carousel.bus');
        owl2.owlCarousel();
        // Go to the next item
        $('.bus.customNextBtn').click(function() {
            owl2.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.bus.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owl2.trigger('prev.owl.carousel', [300]);
        })

        // CARRUSEL 3
        $('#owl-3').owlCarousel({
            loop: true,
            margin:0,
            nav: false,
            responsive: {
                  0: {items:1},
                450: { items:1},
                640: { items:2},
                768: { items:3},
                992: { items:3},
               1200: { items:3}
            }
        });
        var owl3 = $('.owl-carousel.rel');
        owl3.owlCarousel();
        // Go to the next item
        $('.rel.customNextBtn').click(function() {
            owl3.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.rel.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owl3.trigger('prev.owl.carousel', [300]);
        })

        // CARRUSEL PROVEDATOS
        $('#owl-prov').owlCarousel({
            loop: true,
            margin: 15,
            nav: false,
            autoWidth:true,
            responsive: {
                0:   { items: 1},
                450: { items: 1},
                640: { items: 2},
                768: { items: 3},
                992: { items: 5},
                1200:{items: 6}
            }
        });
        var owlProv = $('.owl-carousel.prov');
        owlProv.owlCarousel();
        // Go to the next item
        $('.prov.customNextBtn').click(function() {
            owlProv.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.prov.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owlProv.trigger('prev.owl.carousel', [300]);
        })


        // CARRUSEL DESTACADOS
        $('#owl-dest').owlCarousel({
            loop: true,
            margin:0,
            nav: false,
            responsive: {
                0:   { items:1},
                450: { items:1},
                640: { items:2},
                768: { items:2},
                992: { items:2},
                1200:{ items:2}
            }
        });
        var owlDest = $('.owl-carousel.dest');
        owlDest.owlCarousel();
        // Go to the next item
        $('.dest.customNextBtn').click(function() {
            owlDest.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.dest.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owlDest.trigger('prev.owl.carousel', [300]);
        })


        // CARRUSEL EXPOHIOME
        $('#owl-expohome').owlCarousel({
            loop: true,
            margin:0,
            nav: false,
            responsive: {
                0:   { items:1},
                450: { items:1},
                640: { items:1},
                768: { items:1},
                992: { items:1},
                1200:{ items:1}
            }
        });
        var owlDest = $('.owl-carousel.expohome');
        owlDest.owlCarousel();
        // Go to the next item
        $('.expohome.customNextBtn').click(function() {
            owlDest.trigger('next.owl.carousel');
        })
        // Go to the previous item
        $('.expohome.customPrevBtn').click(function() {
            // With optional speed parameter
            // Parameters has to be in square bracket '[]'
            owlDest.trigger('prev.owl.carousel', [300]);
        })