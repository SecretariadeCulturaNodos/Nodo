
        var mediaquery = window.matchMedia("(max-width:639px)"),
        content = document.querySelector(".content");

        function openNav() {
            document.getElementById("offcanvasAbre").style.display = "none";
            document.getElementById("offcanvasCierra").style.display = "inline-block";
            document.getElementById("resultados").classList.remove("card-exp");
            document.getElementById("sidebar").style.opacity = "1";
            

            if (mediaquery.matches) {
                    document.getElementById("sidebar").style.width = "39vw";
                    document.getElementById("contenido").style.width = "58vw";
                    document.getElementById("contenido").style.marginLeft = "42vw";
                    document.getElementById("offcanvas").style.width = "39vw";
                    document.getElementById("ruta-resultado").style.paddingLeft = "46vw";
                } else {
                    document.getElementById("sidebar").style.width = "25vw";
                    document.getElementById("contenido").style.width = "71vw";
                    document.getElementById("contenido").style.marginLeft = "29vw";
                    document.getElementById("offcanvas").style.width = "25vw";
                    document.getElementById("ruta-resultado").style.paddingLeft = "33vw";
                    document.getElementById("res-rutatop").style.paddingLeft = "9vw";
                } 
            var x = document.getElementsByClassName("pieza-res-img lista");
            var y = document.getElementsByClassName("pieza-res-inf lista");
                var i;
                for (i = 0; i < x.length; i++) {
                    x[i].style.width = "20%";
                    y[i].style.width = "80%";
                }
        }

        function closeNav() {
            if (mediaquery.matches) {
                document.getElementById("offcanvasAbre").style.display = "inline-block";
                document.getElementById("offcanvasCierra").style.display = "none";
                document.getElementById("resultados").classList.add("card-exp");
                document.getElementById("sidebar").style.width = "0";
                document.getElementById("sidebar").style.opacity = "0";
                document.getElementById("contenido").style.width = "100vw";
                document.getElementById("contenido").style.marginLeft = "0vw";
                document.getElementById("res-rutatopx").style.paddingLeft = "4vw";
            } else {
            
                document.getElementById("offcanvasAbre").style.display = "inline-block";
                document.getElementById("offcanvasCierra").style.display = "none";
                document.getElementById("resultados").classList.add("card-exp");
                document.getElementById("sidebar").style.width = "0";
                document.getElementById("sidebar").style.opacity = "0";
                document.getElementById("contenido").style.width = "100vw";
                document.getElementById("contenido").style.marginLeft = "0vw";
                document.getElementById("offcanvas").style.width = "20vw";
                document.getElementById("ruta-resultado").style.paddingLeft = "28vw";
                document.getElementById("res-rutatop").style.paddingLeft = "4vw";
            }
            
            var x = document.getElementsByClassName("pieza-res-img lista");
            var y = document.getElementsByClassName("pieza-res-inf lista");
                var i;
                for (i = 0; i < x.length; i++) {
                    x[i].style.width = "10%";
                    y[i].style.width = "90%";
                }
            
        }


      